package com.mathwheel.client;

import com.mathwheel.Wheel;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.Random;

/** Wheel screen: cards slide, slow down and stop on the result chosen by the server */
public class WheelScreen extends Screen {
	private static final int CARD_W = 124;
	private static final int CARD_H = 48;
	private static final int CYCLES = 16;
	private static final double SPIN_SECONDS = 5.0;
	private static final double HOLD_SECONDS = 2.5;

	private final int result;
	private final String reason;
	private final long startNanos = System.nanoTime();
	private final double jitter = (new Random().nextDouble() - 0.5) * 0.6;

	public WheelScreen(int result, String reason) {
		super(Component.literal("Wheel"));
		this.result = Math.max(0, Math.min(Wheel.LABELS.length - 1, result));
		this.reason = reason;
	}

	@Override
	public boolean shouldCloseOnEsc() {
		return false;
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	private double elapsed() {
		return (System.nanoTime() - startNanos) / 1_000_000_000.0;
	}

	@Override
	public void tick() {
		super.tick();
		if (elapsed() > SPIN_SECONDS + HOLD_SECONDS) {
			this.minecraft.gui.setScreen(null);
		}
	}

	private void centered(GuiGraphicsExtractor g, String s, int cx, int y, float scale, int color) {
		float w = this.font.width(s) * scale;
		g.pose().pushMatrix();
		g.pose().translate(cx - w / 2f, y);
		g.pose().scale(scale, scale);
		g.text(this.font, s, 0, 0, color, true);
		g.pose().popMatrix();
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
		super.extractRenderState(g, mouseX, mouseY, delta);

		double t = elapsed();
		double p = Math.min(1.0, t / SPIN_SECONDS);
		double eased = 1.0 - Math.pow(1.0 - p, 5);

		int n = Wheel.LABELS.length;
		int target = (CYCLES - 3) * n + result;
		double offset = (target * CARD_W + CARD_W / 2.0 + jitter * CARD_W) * eased;

		int cx = this.width / 2;
		int reelW = Math.min(this.width - 20, 5 * CARD_W);
		int rx1 = cx - reelW / 2;
		int rx2 = cx + reelW / 2;
		int ry = this.height / 2 - CARD_H / 2;

		// başlık
		boolean done = p >= 1.0;
		centered(g, done ? "WHEEL STOPPED!" : "SPINNING...", cx, ry - 52, 2.5f, done ? 0xFFFFD700 : 0xFFFF3131);
		centered(g, reason, cx, ry - 24, 1.2f, 0xFFFFFFFF);

		// çerçeve
		g.fill(rx1 - 6, ry - 8, rx2 + 6, ry + CARD_H + 8, 0xF0070B12);
		g.outline(rx1 - 6, ry - 8, reelW + 12, CARD_H + 16, 0xFF2777FF);

		// kartlar (kırpılmış alan içinde)
		g.enableScissor(rx1, ry, rx2, ry + CARD_H);
		int first = Math.max(0, (int) Math.floor((offset - reelW / 2.0) / CARD_W));
		int last = Math.min(CYCLES * n - 1, (int) Math.floor((offset + reelW / 2.0) / CARD_W));
		for (int i = first; i <= last; i++) {
			int idx = i % n;
			int x = (int) Math.round(cx - offset + i * CARD_W);
			boolean winner = done && i == target;
			g.fill(x + 2, ry, x + CARD_W - 2, ry + CARD_H, Wheel.COLORS[idx]);
			g.outline(x + 2, ry, CARD_W - 4, CARD_H, winner ? 0xFFFFFFFF : 0xFF0B0F18);
			String label = Wheel.LABELS[idx];
			float w = this.font.width(label);
			float sc = Math.min(1.3f, (CARD_W - 16f) / w);
			float tw = w * sc;
			g.pose().pushMatrix();
			g.pose().translate(x + (CARD_W - tw) / 2f, ry + (CARD_H - this.font.lineHeight * sc) / 2f);
			g.pose().scale(sc, sc);
			g.text(this.font, label, 0, 0, 0xFFFFFFFF, true);
			g.pose().popMatrix();
		}
		g.disableScissor();

		// orta işaret
		g.fill(cx - 1, ry - 10, cx + 1, ry + CARD_H + 10, 0xFFFFD700);
		g.fill(cx - 5, ry - 12, cx + 5, ry - 9, 0xFFFFD700);
		g.fill(cx - 5, ry + CARD_H + 9, cx + 5, ry + CARD_H + 12, 0xFFFFD700);

		// sonuç
		if (done) {
			int flash = ((int) (t * 4)) % 2 == 0 ? 0xFFFFFFFF : 0xFFFFD700;
			centered(g, "PENALTY: " + Wheel.LABELS[result], cx, ry + CARD_H + 26, 2.0f, flash);
		}
	}
}
