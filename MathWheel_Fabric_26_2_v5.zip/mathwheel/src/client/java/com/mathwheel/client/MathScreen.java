package com.mathwheel.client;

import com.mathwheel.Payloads;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/** Question screen: big question card, timer bar and five answer buttons (A-E). One click = answer. */
public class MathScreen extends Screen {
	private static final int W = 300;
	private static final String[] LEVEL_NAMES = {"", "EASY", "MEDIUM", "HARD"};
	private static final int[] LEVEL_COLORS = {0, 0xFF00FF41, 0xFFFFB000, 0xFFFF3131};

	private final Payloads.ProblemPayload problem;
	private final String[] lines;
	private final String[] options;
	private final long startNanos = System.nanoTime();
	private final List<Button> buttons = new ArrayList<>();

	private boolean sent = false;
	private int px, py;

	private String correctMessage = null;
	private long correctNanos = 0;

	public MathScreen(Payloads.ProblemPayload problem) {
		super(Component.literal("Math Wheel"));
		this.problem = problem;
		this.lines = problem.equation().split("\n");
		this.options = problem.options().split("\\|");
	}

	@Override
	protected void init() {
		px = (this.width - W) / 2;
		py = Math.max(6, (this.height - 250) / 2);

		buttons.clear();
		for (int i = 0; i < options.length; i++) {
			final int idx = i;
			Button b = Button.builder(Component.literal((char) ('A' + i) + ")   " + options[i]), btn -> choose(idx))
				.bounds(px, py + 120 + i * 25, W, 22).build();
			if (sent) b.active = false;
			buttons.add(b);
			this.addRenderableWidget(b);
		}
	}

	private void choose(int index) {
		if (sent) return;
		sent = true;
		ClientPlayNetworking.send(new Payloads.AnswerPayload(problem.id(), Integer.toString(index)));
		for (Button b : buttons) b.active = false;
	}

	/** Called when the server says "correct" */
	public void showCorrect(String message) {
		this.correctMessage = message;
		this.correctNanos = System.nanoTime();
	}

	@Override
	public boolean shouldCloseOnEsc() {
		return false; // no escaping with ESC
	}

	@Override
	public boolean isPauseScreen() {
		return false; // game keeps running
	}

	@Override
	public void tick() {
		super.tick();
		if (correctMessage != null && (System.nanoTime() - correctNanos) / 1_000_000_000.0 > 1.6) {
			this.minecraft.gui.setScreen(null);
		}
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
		super.extractRenderState(g, mouseX, mouseY, delta);

		int lvl = Math.max(1, Math.min(3, problem.level()));
		int accent = LEVEL_COLORS[lvl];

		// ---- title bar (terminal style)
		g.fill(px, py, px + W, py + 16, 0xFF0B3A99);
		g.outline(px, py, W, 16, 0xFF2777FF);
		g.text(this.font, "root@minecraft:~# math --wheel", px + 6, py + 4, 0xFF00FF41, true);
		String lvlName = "LEVEL: " + LEVEL_NAMES[lvl];
		g.text(this.font, lvlName, px + W - this.font.width(lvlName) - 6, py + 4, accent, true);

		// ---- question card
		int cy = py + 20, ch = 72;
		g.fill(px, cy, px + W, cy + ch, 0xF0070B12);
		for (int y = cy + 2; y < cy + ch; y += 4) {
			g.fill(px + 1, y, px + W - 1, y + 1, 0x10FFFFFF); // scan lines
		}
		g.outline(px, cy, W, ch, accent);

		// difficulty dots
		for (int i = 0; i < 3; i++) {
			int bx = px + 8 + i * 12;
			g.fill(bx, cy + ch - 9, bx + 9, cy + ch - 4, i < lvl ? accent : 0xFF1B2D4A);
		}

		// question lines (scaled to fit)
		int maxW = 1;
		for (String ln : lines) maxW = Math.max(maxW, this.font.width(ln));
		int n = lines.length;
		float lh = this.font.lineHeight;
		float scale = Math.min(3.0f, (W - 24f) / maxW);
		scale = Math.min(scale, (ch - 16f - (n - 1) * 4f) / (n * lh));
		scale = Math.max(1.0f, scale);
		float totalH = n * lh * scale + (n - 1) * 4f;
		float yy = cy + (ch - 10f - totalH) / 2f;
		for (String ln : lines) {
			float w = this.font.width(ln) * scale;
			g.pose().pushMatrix();
			g.pose().translate(px + (W - w) / 2f, yy);
			g.pose().scale(scale, scale);
			g.text(this.font, ln, 0, 0, 0xFFFFFFFF, true);
			g.pose().popMatrix();
			yy += lh * scale + 4f;
		}

		// ---- timer bar
		double elapsed = (System.nanoTime() - startNanos) / 1_000_000_000.0;
		double remaining = Math.max(0, problem.seconds() - elapsed);
		float frac = (float) (remaining / problem.seconds());
		int barColor = frac > 0.5f ? 0xFF00FF41 : frac > 0.25f ? 0xFFFFB000 : 0xFFFF3131;
		g.fill(px, py + 96, px + W, py + 104, 0xFF111820);
		g.fill(px + 1, py + 97, px + 1 + (int) ((W - 2) * frac), py + 103, barColor);
		g.outline(px, py + 96, W, 8, 0xFF2777FF);

		String timeText = "TIME: " + (int) Math.ceil(remaining) + " s";
		g.text(this.font, timeText, px + W - this.font.width(timeText), py + 107, barColor, true);
		String status = sent ? "Answer sent, waiting..." : "Click the correct answer";
		g.text(this.font, status, px, py + 107, sent ? 0xFFFFB000 : 0xFF8FA3C8, true);

		// ---- correct answer overlay
		if (correctMessage != null) {
			g.fill(px, cy, px + W, cy + ch, 0xF0052A12);
			g.outline(px, cy, W, ch, 0xFF00FF41);
			float s2 = 1.6f;
			float w2 = this.font.width(correctMessage) * s2;
			g.pose().pushMatrix();
			g.pose().translate(px + (W - w2) / 2f, cy + ch / 2f - 7f);
			g.pose().scale(s2, s2);
			g.text(this.font, correctMessage, 0, 0, 0xFF00FF41, true);
			g.pose().popMatrix();
		}
	}
}
