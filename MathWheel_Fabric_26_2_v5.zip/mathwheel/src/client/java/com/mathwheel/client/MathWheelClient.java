package com.mathwheel.client;

import com.mathwheel.Payloads;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.Minecraft;

public class MathWheelClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		// New question -> open question screen
		ClientPlayNetworking.registerGlobalReceiver(Payloads.ProblemPayload.TYPE, (payload, context) -> {
			Minecraft mc = context.client();
			mc.execute(() -> mc.gui.setScreen(new MathScreen(payload)));
		});

		// Correct answer -> show green overlay, then close
		ClientPlayNetworking.registerGlobalReceiver(Payloads.ResultPayload.TYPE, (payload, context) -> {
			Minecraft mc = context.client();
			mc.execute(() -> {
				if (mc.gui.screen() instanceof MathScreen ms) {
					ms.showCorrect(payload.message());
				}
			});
		});

		// Spin the wheel
		ClientPlayNetworking.registerGlobalReceiver(Payloads.SpinPayload.TYPE, (payload, context) -> {
			Minecraft mc = context.client();
			mc.execute(() -> mc.gui.setScreen(new WheelScreen(payload.result(), payload.reason())));
		});
	}
}
