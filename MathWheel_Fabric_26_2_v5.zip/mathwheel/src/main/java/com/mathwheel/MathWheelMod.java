package com.mathwheel;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/**
 * Math Wheel (server side)
 * - Every minute a multiple-choice question (A-E) opens on every player's screen.
 * - Wrong answer or timeout -> the WHEEL spins (animation on client) and a penalty is applied.
 */
public class MathWheelMod implements ModInitializer {
	public static final String MOD_ID = "mathwheel";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	// ================= SETTINGS =================
	/** Ticks between questions (20 ticks = 1 second). 1200 = 1 minute */
	private static final int PERIOD_TICKS = 20 * 60;
	/** Answer time = BASE + PER_LEVEL * level (seconds). Must stay below the period. */
	private static final int SOLVE_BASE_SECONDS = 30;
	private static final int SOLVE_PER_LEVEL_SECONDS = 5;
	/** Ticks from wheel start until the penalty is applied (client animation is 5 s) */
	private static final int SPIN_APPLY_TICKS = 20 * 5 + 6;
	/** Fraction of inventory slots to wipe (0.25 = 25%) */
	private static final double INVENTORY_WIPE_RATIO = 0.25;
	/** "Nearest block": how far to look for the nearest block */
	private static final int BLOCK_SEARCH_RADIUS = 3;
	/** Banned block types are removed from every chunk within this many chunks of a player */
	private static final int BAN_SCAN_RADIUS_CHUNKS = 8;
	/** Max chunks scanned per server tick (keeps the server smooth) */
	private static final int BAN_SCANS_PER_TICK = 2;
	/** Vertical scan range for banned blocks */
	private static final int BAN_MIN_Y = -64;
	private static final int BAN_MAX_Y = 320;

	/** { command name, display name } */
	private static final String[][] MOBS = {
		{"zombie", "Zombie"},
		{"skeleton", "Skeleton"},
		{"spider", "Spider"},
		{"cave_spider", "Cave Spider"},
		{"creeper", "Creeper"},
		{"husk", "Husk"},
		{"stray", "Stray"},
		{"vindicator", "Vindicator"},
		{"pillager", "Pillager"},
		{"witch", "Witch"}
	};
	// ============================================

	private static final Random RNG = new Random();
	private static final Map<UUID, State> STATES = new HashMap<>();
	private static final Set<UUID> WARNED = new HashSet<>();
	private static long tick = 0;
	private static long idCounter = 0;

	/** Block types banned by the wheel. They are removed everywhere, in every chunk players go to. */
	private static final Set<Block> BANNED = new HashSet<>();
	/** Chunks already cleaned for the current ban list, per dimension */
	private static final Map<Level, Set<Long>> SCANNED = new HashMap<>();

	private static final class State {
		long id;
		int correctIndex;
		String correctLabel = "";
		long deadlineTick;
		boolean active;
		long applyAtTick = -1;
		int pendingResult;
	}

	@Override
	public void onInitialize() {
		PayloadTypeRegistry.clientboundPlay().register(Payloads.ProblemPayload.TYPE, Payloads.ProblemPayload.CODEC);
		PayloadTypeRegistry.clientboundPlay().register(Payloads.ResultPayload.TYPE, Payloads.ResultPayload.CODEC);
		PayloadTypeRegistry.clientboundPlay().register(Payloads.SpinPayload.TYPE, Payloads.SpinPayload.CODEC);
		PayloadTypeRegistry.serverboundPlay().register(Payloads.AnswerPayload.TYPE, Payloads.AnswerPayload.CODEC);

		ServerPlayNetworking.registerGlobalReceiver(Payloads.AnswerPayload.TYPE, (payload, context) -> {
			ServerPlayer p = context.player();
			context.server().execute(() -> onAnswer(p, payload));
		});

		// Test commands
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
			dispatcher.register(Commands.literal("mathwheel")
				.then(Commands.literal("now").executes(ctx -> {
					ServerPlayer p = ctx.getSource().getPlayerOrException();
					State s = STATES.get(p.getUUID());
					if (s != null && s.active) {
						p.sendSystemMessage(lit("&7You already have a question to solve."));
						return 0;
					}
					newProblem(p);
					return 1;
				}))
				.then(Commands.literal("wheel").executes(ctx -> {
					ServerPlayer p = ctx.getSource().getPlayerOrException();
					startSpin(p, stateOf(p), "TEST WHEEL");
					return 1;
				}))
				.then(Commands.literal("block").executes(ctx -> {
					ServerPlayer p = ctx.getSource().getPlayerOrException();
					removeNearestBlock(p);
					return 1;
				}))
				.then(Commands.literal("unban").executes(ctx -> {
					ServerPlayer p = ctx.getSource().getPlayerOrException();
					BANNED.clear();
					SCANNED.clear();
					p.sendSystemMessage(lit("&aAll banned blocks cleared."));
					return 1;
				}))));

		ServerTickEvents.END_SERVER_TICK.register(this::onServerTick);
		LOGGER.info("Math Wheel loaded!");
	}

	// ---------------------------------------------------------------- tick

	private void onServerTick(MinecraftServer server) {
		tick++;
		List<ServerPlayer> players = server.getPlayerList().getPlayers();

		if (tick % PERIOD_TICKS == 0) {
			STATES.keySet().removeIf(id -> players.stream().noneMatch(p -> p.getUUID().equals(id)));
			for (ServerPlayer p : players) {
				if (p.isAlive() && !p.isSpectator()) {
					newProblem(p);
				}
			}
		}

		if (!BANNED.isEmpty()) {
			enforceBans(players);
		}

		for (ServerPlayer p : players) {
			State s = STATES.get(p.getUUID());
			if (s == null) continue;

			if (s.active && tick >= s.deadlineTick) {
				s.active = false;
				startSpin(p, s, "TIME'S UP! Correct answer: " + s.correctLabel);
			}
			if (s.applyAtTick >= 0 && tick >= s.applyAtTick) {
				s.applyAtTick = -1;
				if (p.isAlive()) {
					apply(server, p, s.pendingResult);
				}
			}
		}
	}

	// ------------------------------------------------------------ questions

	private static State stateOf(ServerPlayer p) {
		return STATES.computeIfAbsent(p.getUUID(), k -> new State());
	}

	private static void newProblem(ServerPlayer p) {
		if (!ServerPlayNetworking.canSend(p, Payloads.ProblemPayload.TYPE)) {
			if (WARNED.add(p.getUUID())) {
				p.sendSystemMessage(lit("&cMath Wheel mod is not installed on your client, question could not be sent."));
			}
			return;
		}
		Problems.Problem pr = Problems.next();
		State s = stateOf(p);
		s.id = ++idCounter;
		s.correctIndex = pr.correctIndex();
		s.correctLabel = pr.correctLabel();
		int seconds = SOLVE_BASE_SECONDS + SOLVE_PER_LEVEL_SECONDS * pr.level();
		s.deadlineTick = tick + seconds * 20L;
		s.active = true;
		ServerPlayNetworking.send(p, new Payloads.ProblemPayload(
			s.id, pr.text(), seconds, pr.level(), String.join("|", pr.options())));
	}

	private static void onAnswer(ServerPlayer p, Payloads.AnswerPayload payload) {
		State s = STATES.get(p.getUUID());
		if (s == null || !s.active || s.id != payload.id()) return;
		s.active = false;

		int picked = -1;
		try {
			picked = Integer.parseInt(payload.answer().trim());
		} catch (NumberFormatException ignored) {
			// invalid = wrong
		}

		if (picked == s.correctIndex) {
			ServerPlayNetworking.send(p, new Payloads.ResultPayload("CORRECT! No wheel this time."));
		} else {
			startSpin(p, s, "WRONG! Correct answer: " + s.correctLabel);
		}
	}

	// ------------------------------------------------------------------ wheel

	private static void startSpin(ServerPlayer p, State s, String reason) {
		int result = RNG.nextInt(Wheel.LABELS.length);
		s.pendingResult = result;
		s.applyAtTick = tick + SPIN_APPLY_TICKS;
		ServerPlayNetworking.send(p, new Payloads.SpinPayload(result, reason));
	}

	private static void apply(MinecraftServer server, ServerPlayer p, int result) {
		p.sendSystemMessage(lit("&c&lWHEEL: &f" + Wheel.LABELS[result]));
		switch (result) {
			case 0 -> damage(server, p, 2);   // 1 heart = 2 hp
			case 1 -> wipeInventory(p);
			case 2 -> damage(server, p, 10);  // 5 hearts = 10 hp
			case 3 -> removeNearestBlock(p);
			default -> summonHostile(server, p);
		}
	}

	// ---------------------------------------------------------------- penalties

	private static void damage(MinecraftServer server, ServerPlayer p, int amount) {
		run(server, "damage " + p.getStringUUID() + " " + amount + " minecraft:magic");
	}

	private static void wipeInventory(ServerPlayer p) {
		Inventory inv = p.getInventory();
		List<Integer> filled = new ArrayList<>();
		for (int i = 0; i < inv.getContainerSize(); i++) {
			if (!inv.getItem(i).isEmpty()) filled.add(i);
		}
		if (filled.isEmpty()) {
			p.sendSystemMessage(lit("&7Your inventory is already empty, lucky you."));
			return;
		}
		Collections.shuffle(filled, RNG);
		int remove = Math.max(1, (int) Math.ceil(filled.size() * INVENTORY_WIPE_RATIO));
		for (int i = 0; i < remove; i++) {
			inv.setItem(filled.get(i), ItemStack.EMPTY);
		}
		p.sendSystemMessage(lit("&c" + remove + " &fslot(s) wiped from your inventory!"));
	}

	/**
	 * Finds the nearest block and BANS its type: every block of that type is deleted,
	 * not just nearby ones. It also keeps being deleted in every chunk players enter.
	 */
	private static void removeNearestBlock(ServerPlayer p) {
		Level level = p.level();
		BlockPos base = p.blockPosition();
		double px = p.getX(), py = p.getY() + 0.9, pz = p.getZ();

		BlockPos best = null;
		double bestDist = Double.MAX_VALUE;
		int R = BLOCK_SEARCH_RADIUS;
		for (int dx = -R; dx <= R; dx++) {
			for (int dy = -R; dy <= R; dy++) {
				for (int dz = -R; dz <= R; dz++) {
					BlockPos pos = base.offset(dx, dy, dz);
					BlockState st = level.getBlockState(pos);
					if (st.isAir() || !st.getFluidState().isEmpty()) continue;
					if (st.getDestroySpeed(level, pos) < 0) continue; // bedrock etc.
					double ex = pos.getX() + 0.5 - px;
					double ey = pos.getY() + 0.5 - py;
					double ez = pos.getZ() + 0.5 - pz;
					double d = ex * ex + ey * ey + ez * ez;
					if (d < bestDist) {
						bestDist = d;
						best = pos;
					}
				}
			}
		}

		if (best == null) {
			p.sendSystemMessage(lit("&7No block nearby to ban, lucky you."));
			return;
		}

		Block target = level.getBlockState(best).getBlock();
		String name = target.toString().replace("Block{", "").replace("}", "");
		if (BANNED.add(target)) {
			SCANNED.clear(); // ban list changed -> all chunks need a fresh clean
		}

		// instant effect: clean the chunks around the player right now
		int pcx = base.getX() >> 4, pcz = base.getZ() >> 4;
		int removed = 0;
		for (int cx = pcx - 2; cx <= pcx + 2; cx++) {
			for (int cz = pcz - 2; cz <= pcz + 2; cz++) {
				removed += scanChunk(level, cx, cz);
			}
		}
		p.sendSystemMessage(lit("&c" + name + " &fis now banned! &c" + removed
			+ " &fremoved so far, the rest vanishes in every chunk you enter."));
	}

	/** Cleans banned blocks near each player, a few chunks per tick, nearest first */
	private static void enforceBans(List<ServerPlayer> players) {
		int budget = BAN_SCANS_PER_TICK;
		for (ServerPlayer p : players) {
			Level level = p.level();
			Set<Long> done = SCANNED.computeIfAbsent(level, k -> new HashSet<>());
			int pcx = p.blockPosition().getX() >> 4;
			int pcz = p.blockPosition().getZ() >> 4;

			// the chunk you stand in is re-cleaned every second (catches blocks you place)
			if (tick % 20 == 0) {
				scanChunk(level, pcx, pcz);
			}

			outer:
			for (int r = 0; r <= BAN_SCAN_RADIUS_CHUNKS; r++) {
				for (int dx = -r; dx <= r; dx++) {
					for (int dz = -r; dz <= r; dz++) {
						if (Math.max(Math.abs(dx), Math.abs(dz)) != r) continue;
						if (budget <= 0) break outer;
						int cx = pcx + dx, cz = pcz + dz;
						long key = ((long) cx & 0xffffffffL) | (((long) cz & 0xffffffffL) << 32);
						if (done.contains(key)) continue;
						if (!level.hasChunkAt(new BlockPos(cx * 16, 64, cz * 16))) continue; // not loaded yet
						scanChunk(level, cx, cz);
						done.add(key);
						budget--;
					}
				}
			}
		}
	}

	/** Removes every banned block in one chunk column. Returns how many were removed. */
	private static int scanChunk(Level level, int cx, int cz) {
		int removed = 0;
		int x0 = cx << 4, z0 = cz << 4;
		BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
		for (int x = 0; x < 16; x++) {
			for (int z = 0; z < 16; z++) {
				for (int y = BAN_MIN_Y; y <= BAN_MAX_Y; y++) {
					pos.set(x0 + x, y, z0 + z);
					BlockState st = level.getBlockState(pos);
					if (st.isAir()) continue;
					if (!BANNED.contains(st.getBlock())) continue;
					if (st.getDestroySpeed(level, pos) < 0) continue;
					level.setBlock(pos.immutable(), Blocks.AIR.defaultBlockState(), 2);
					removed++;
				}
			}
		}
		return removed;
	}

	private static void summonHostile(MinecraftServer server, ServerPlayer p) {
		String[] mob = MOBS[RNG.nextInt(MOBS.length)];
		run(server, "execute as " + p.getStringUUID() + " at @s run summon minecraft:" + mob[0] + " ~ ~ ~");
		p.sendSystemMessage(lit("&cA " + mob[1] + " is attacking you!"));
	}

	// -------------------------------------------------------------- helpers

	private static void run(MinecraftServer server, String command) {
		try {
			CommandSourceStack src = server.createCommandSourceStack().withSuppressedOutput();
			server.getCommands().getDispatcher().execute(command, src);
		} catch (Exception e) {
			LOGGER.error("Could not run command: {}", command, e);
		}
	}

	/** Converts '&' color codes to Minecraft color codes */
	private static Component lit(String text) {
		return Component.literal(text.replace('&', '\u00a7'));
	}
}
