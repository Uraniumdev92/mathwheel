package com.mathwheel;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Sunucu <-> istemci paketleri */
public final class Payloads {
	private Payloads() {}

	private static Identifier ident(String path) {
		return Identifier.fromNamespaceAndPath(MathWheelMod.MOD_ID, path);
	}

	/** Server -> Client: new question (options joined with "|") */
	public record ProblemPayload(long id, String equation, int seconds, int level, String options) implements CustomPacketPayload {
		public static final CustomPacketPayload.Type<ProblemPayload> TYPE = new CustomPacketPayload.Type<>(ident("problem"));
		public static final StreamCodec<RegistryFriendlyByteBuf, ProblemPayload> CODEC = StreamCodec.composite(
			ByteBufCodecs.LONG, ProblemPayload::id,
			ByteBufCodecs.STRING_UTF8, ProblemPayload::equation,
			ByteBufCodecs.INT, ProblemPayload::seconds,
			ByteBufCodecs.INT, ProblemPayload::level,
			ByteBufCodecs.STRING_UTF8, ProblemPayload::options,
			ProblemPayload::new);

		@Override
		public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
			return TYPE;
		}
	}

	/** İstemci -> Sunucu: verilen cevap */
	public record AnswerPayload(long id, String answer) implements CustomPacketPayload {
		public static final CustomPacketPayload.Type<AnswerPayload> TYPE = new CustomPacketPayload.Type<>(ident("answer"));
		public static final StreamCodec<RegistryFriendlyByteBuf, AnswerPayload> CODEC = StreamCodec.composite(
			ByteBufCodecs.LONG, AnswerPayload::id,
			ByteBufCodecs.STRING_UTF8, AnswerPayload::answer,
			AnswerPayload::new);

		@Override
		public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
			return TYPE;
		}
	}

	/** Sunucu -> İstemci: doğru cevap */
	public record ResultPayload(String message) implements CustomPacketPayload {
		public static final CustomPacketPayload.Type<ResultPayload> TYPE = new CustomPacketPayload.Type<>(ident("result"));
		public static final StreamCodec<RegistryFriendlyByteBuf, ResultPayload> CODEC = StreamCodec.composite(
			ByteBufCodecs.STRING_UTF8, ResultPayload::message,
			ResultPayload::new);

		@Override
		public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
			return TYPE;
		}
	}

	/** Sunucu -> İstemci: çark dönsün (sonuç önceden belli, istemci sadece animasyonu oynatır) */
	public record SpinPayload(int result, String reason) implements CustomPacketPayload {
		public static final CustomPacketPayload.Type<SpinPayload> TYPE = new CustomPacketPayload.Type<>(ident("spin"));
		public static final StreamCodec<RegistryFriendlyByteBuf, SpinPayload> CODEC = StreamCodec.composite(
			ByteBufCodecs.INT, SpinPayload::result,
			ByteBufCodecs.STRING_UTF8, SpinPayload::reason,
			SpinPayload::new);

		@Override
		public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
			return TYPE;
		}
	}
}
