package com.mathwheel;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

/**
 * Endless random multiple-choice question generator (5 options, A-E).
 * Level 1 = easy, 2 = medium, 3 = hard (still simple, e.g. 7^x = 49).
 * Every call makes brand new random numbers, so questions never run out.
 */
public final class Problems {
	private Problems() {}

	public record Problem(String text, int level, List<String> options, int correctIndex) {
		public String correctLabel() {
			return (char) ('A' + correctIndex) + ") " + options.get(correctIndex);
		}
	}

	private static final Random RNG = new Random();

	private static int r(int min, int max) {
		return min + RNG.nextInt(max - min + 1);
	}

	/** Random level: 40% easy, 35% medium, 25% hard */
	public static Problem next() {
		int roll = RNG.nextInt(100);
		return make(roll < 40 ? 1 : roll < 75 ? 2 : 3);
	}

	public static Problem make(int level) {
		switch (level) {
			case 1:
				switch (RNG.nextInt(7)) {
					case 0: return decDiv();
					case 1: return decMul();
					case 2: return percentEasy();
					case 3: return addSub();
					case 4: return mulSmall();
					case 5: return sqrtPerfect();
					default: return decDiv();
				}
			case 2:
				switch (RNG.nextInt(7)) {
					case 0: return linear();
					case 1: return twoDigitMul();
					case 2: return orderOps();
					case 3: return fracOf();
					case 4: return squaresDiff();
					case 5: return percentMid();
					default: return linear();
				}
			default:
				switch (RNG.nextInt(7)) {
					case 0: return expSolve();
					case 1: return expSolve();
					case 2: return sqEq();
					case 3: return sysSimple();
					case 4: return linearBothSides();
					case 5: return divEq();
					default: return percentReverse();
				}
		}
	}

	// ------------------------------------------------------------ option builder

	/** Builds 5 unique options (one correct, shuffled). 'extras' are plausible wrong answers. */
	private static Problem build(String text, long answer, int level, long... extras) {
		List<Long> ex = new ArrayList<>();
		for (long e : extras) {
			if (e != answer && !ex.contains(e) && !(answer >= 0 && e < 0)) ex.add(e);
		}
		Collections.shuffle(ex, RNG);

		Set<Long> set = new LinkedHashSet<>();
		set.add(answer);
		for (int i = 0; i < ex.size() && set.size() < 3; i++) set.add(ex.get(i));

		long[] steps = {1, 2, 3, 5, 10, Math.max(1, Math.abs(answer) / 10), Math.max(1, Math.abs(answer) / 5)};
		int guard = 0;
		while (set.size() < 5 && guard++ < 300) {
			long step = steps[RNG.nextInt(steps.length)] * r(1, 3);
			long c = answer + (RNG.nextBoolean() ? step : -step);
			if (answer >= 0 && c < 0) continue;
			set.add(c);
		}
		long fill = answer + 1;
		while (set.size() < 5) set.add(fill++);

		List<Long> list = new ArrayList<>(set);
		Collections.shuffle(list, RNG);
		List<String> opts = new ArrayList<>();
		for (long v : list) opts.add(Long.toString(v));
		return new Problem(text, level, opts, list.indexOf(answer));
	}

	private static long pow(long b, int e) {
		long v = 1;
		for (int i = 0; i < e; i++) v *= b;
		return v;
	}

	// ------------------------------------------------------------ level 1 (easy)

	/** e.g. 580 ÷ 0.58 = ? */
	private static Problem decDiv() {
		int m = r(11, 99), q = r(2, 20);
		long dividend = (long) m * q;
		long ans = 100L * q;
		String divisor = String.format("0.%02d", m);
		return build(dividend + " ÷ " + divisor + " = ?", ans, 1, 10L * q, 1000L * q, q);
	}

	/** e.g. 0.4 × 350 = ? */
	private static Problem decMul() {
		int t = r(2, 9), k = r(5, 60);
		long n = 10L * k;
		long ans = (long) t * k;
		return build("0." + t + " × " + n + " = ?", ans, 1, ans * 10, ans * 100, n + t);
	}

	private static Problem percentEasy() {
		int[] ps = {5, 10, 20, 25, 50};
		int p = ps[RNG.nextInt(ps.length)];
		long base = 20L * r(2, 40);
		long ans = base * p / 100;
		return build(p + "% of " + base + " = ?", ans, 1, base - ans, ans * 10, base / 10);
	}

	private static Problem addSub() {
		int a = r(120, 899), b = r(110, 899);
		if (RNG.nextBoolean()) {
			long ans = a + b;
			return build(a + " + " + b + " = ?", ans, 1, ans + 10, ans - 10, ans + 100);
		}
		int hi = Math.max(a, b), lo = Math.min(a, b);
		long ans = hi - lo;
		return build(hi + " - " + lo + " = ?", ans, 1, ans + 10, ans - 10, ans + 100);
	}

	private static Problem mulSmall() {
		int a = r(12, 35), b = r(3, 9);
		long ans = (long) a * b;
		return build(a + " × " + b + " = ?", ans, 1, ans + a, ans - b, ans + 10);
	}

	private static Problem sqrtPerfect() {
		int n = r(6, 20);
		return build("sqrt(" + (n * n) + ") = ?", n, 1, n + 1, n - 1, 2L * n);
	}

	// ------------------------------------------------------------ level 2 (medium)

	/** e.g. 3x + 7 = 31  ->  x = ? */
	private static Problem linear() {
		int a = r(2, 9), x = r(2, 15), b = r(1, 30);
		return build(a + "x + " + b + " = " + (a * x + b) + "\nx = ?", x, 2, x + 1, x - 1, (long) a * x + b);
	}

	private static Problem twoDigitMul() {
		int a = r(21, 59), b = r(11, 19);
		long ans = (long) a * b;
		return build(a + " × " + b + " = ?", ans, 2, ans + 10, ans - 10, ans + a);
	}

	private static Problem orderOps() {
		int a = r(5, 30), b = r(3, 9), c = r(3, 9);
		if (RNG.nextBoolean()) {
			long ans = a + (long) b * c;
			return build(a + " + " + b + " × " + c + " = ?", ans, 2, (long) (a + b) * c, ans + 1, ans - 1);
		}
		long ans = (long) a * b - c;
		return build(a + " × " + b + " - " + c + " = ?", ans, 2, ans + 2L * c, ans + 1, ans - 1);
	}

	private static Problem fracOf() {
		int[] ds = {2, 3, 4, 5, 6, 8, 10};
		int d = ds[RNG.nextInt(ds.length)];
		int n = r(1, d - 1);
		long base = (long) d * r(6, 30);
		long ans = base / d * n;
		return build(n + "/" + d + " of " + base + " = ?", ans, 2, base / d, base - ans, ans + n);
	}

	private static Problem squaresDiff() {
		int a = r(8, 20), b = r(2, 9);
		long ans = (long) a * a - (long) b * b;
		return build(a + "² - " + b + "² = ?", ans, 2, (long) a * a + (long) b * b, (long) (a - b) * (a - b), ans + 2);
	}

	private static Problem percentMid() {
		int[] ps = {15, 30, 40, 60, 75};
		int p = ps[RNG.nextInt(ps.length)];
		long base = 20L * r(5, 40);
		long ans = base * p / 100;
		return build(p + "% of " + base + " = ?", ans, 2, base - ans, ans * 10, ans + 10);
	}

	// ------------------------------------------------------------ level 3 (hardest, still easy)

	/** e.g. 7^x = 49  ->  x = ? */
	private static Problem expSolve() {
		int b = r(2, 9), x = r(2, 4);
		return build(b + "^x = " + pow(b, x) + "\nx = ?", x, 3, b, x + 1, x - 1);
	}

	private static Problem sqEq() {
		int x = r(3, 15);
		return build("x² = " + (x * x) + "\nx = ? (x > 0)", x, 3, x + 1, x - 1, (long) x * 2);
	}

	private static Problem sysSimple() {
		int x = r(5, 20), y = r(1, x - 1);
		return build("x + y = " + (x + y) + "\nx - y = " + (x - y) + "\nx = ?", x, 3, y, x + y, x - y);
	}

	/** e.g. 5x + 4 = 2x + 25 */
	private static Problem linearBothSides() {
		int x = r(2, 12), a = r(3, 8), c = r(1, a - 1), b = r(1, 20);
		int d = a * x + b - c * x;
		return build(a + "x + " + b + " = " + c + "x + " + d + "\nx = ?", x, 3, x + 1, x - 1, d);
	}

	private static Problem divEq() {
		int k = r(2, 9), m = r(2, 12), b = r(1, 15);
		long x = (long) k * m;
		return build("x ÷ " + k + " + " + b + " = " + (m + b) + "\nx = ?", x, 3, m, m + b, x + k);
	}

	private static Problem percentReverse() {
		int[] ps = {10, 20, 25, 50};
		int p = ps[RNG.nextInt(ps.length)];
		int k = r(2, 30);
		long x = 100L * k / p;
		return build(p + "% of x = " + k + "\nx = ?", x, 3, k, x + p, x * 2);
	}
}
