package com.mathwheel;

/** Things the wheel can land on. Order matches the cases in MathWheelMod.apply(). */
public final class Wheel {
	private Wheel() {}

	public static final String[] LABELS = {
		"-1 Heart",
		"25% Inventory Wiped",
		"-5 Hearts",
		"Nearest Block Deleted",
		"Mob Attacks You"
	};

	/** Card colors (ARGB) */
	public static final int[] COLORS = {
		0xFFD14B4B,
		0xFFC98A1B,
		0xFF7A1020,
		0xFF2777FF,
		0xFF1F9A3A
	};
}
