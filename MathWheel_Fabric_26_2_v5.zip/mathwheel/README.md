# Math Wheel (Fabric 26.2)

Every minute a multiple-choice math question (A-E) opens on your screen.
Click the right answer. Wrong answer or time out = the WHEEL spins and you get a penalty:
-1 heart, 25% of inventory wiped, -5 hearts, nearest block type banned worldwide (deleted in every chunk you enter), or a random mob attacks.

Questions are generated randomly and endlessly (easy: `580 ÷ 0.58`, hardest: `7^x = 49`).

## Build
1. Install JDK 25 (Temurin).
2. `.\gradlew.bat build` (Windows) or `./gradlew build`
3. Jar: `build/libs/mathwheel-1.0.0.jar` (not the `-sources` one)

## Install
Put the jar on the SERVER and on EVERY PLAYER (UI is client side, penalties are server side).
Fabric API is required on both.

## Settings
Top of `MathWheelMod.java` (period, time, inventory %, block radius). Wheel options: `Wheel.java`. Questions: `Problems.java`.

## Test commands
- `/mathwheel now`   -> ask a question right now
- `/mathwheel wheel` -> spin the wheel right now
- `/mathwheel block` -> test the block ban
- `/mathwheel unban` -> clear all banned blocks
